#ifndef LOADER_H
#define LOADER_H

#include "world.h"
#include "object.h"
#include <stdbool.h>

/**
 * @brief Charge les définitions d’objets depuis un fichier .stv
 * @param path chemin du fichier objects.stv
 * @param outArray tableau de sortie
 * @param maxObjects taille max du tableau
 * @return nombre d’objets chargés
 */
int load_objects_from_stv(const char* path, ObjectType* outArray, int maxObjects);

/**
 * @brief Charge les définitions de types de pièces depuis un fichier .stv
 * @param path chemin du fichier rooms.stv
 * @param outArray tableau de sortie
 * @param maxRooms taille max du tableau
 * @return nombre de règles de pièces chargées
 */
int load_rooms_from_stv(const char* path, RoomTypeRule* outArray, int maxRooms, const ObjectType* objects, int objectCount);

/**
 * @brief Helper pour retrouver un objet par son nom (dans les rooms)
 */
const ObjectType* find_object_by_name(const ObjectType* objects, int count, const char* name);

void debug_print_rooms(const RoomTypeRule* rooms, int roomCount, const ObjectType* objects, int objectCount);
void debug_print_objects(const ObjectType* objects, int count);
#endif // LOADER_H
