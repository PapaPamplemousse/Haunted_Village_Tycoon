#ifndef TILE_LOADER_H
#define TILE_LOADER_H

#include "world.h"

int load_tiles_from_stv(const char* path, TileType* outArray, int maxTiles);

#endif // TILE_LOADER_H
