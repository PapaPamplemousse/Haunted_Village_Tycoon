#ifndef BIOME_LOADER_H
#define BIOME_LOADER_H

#include "world.h"

extern BiomeDef gBiomeDefs[];
extern int      gBiomeCount;

void            load_biome_definitions(const char* path);
const char*     get_biome_name(BiomeKind k);
const BiomeDef* get_biome_def(BiomeKind kind);
BiomeKind       biome_kind_from_string(const char* s);
const char*     biome_kind_to_string(BiomeKind k);

#endif
