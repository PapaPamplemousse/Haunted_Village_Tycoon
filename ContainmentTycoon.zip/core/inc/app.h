
#ifndef APP_H
#define APP_H

/**
 * @brief Runs the main application loop.
 */
void app_run(void);

#endif
